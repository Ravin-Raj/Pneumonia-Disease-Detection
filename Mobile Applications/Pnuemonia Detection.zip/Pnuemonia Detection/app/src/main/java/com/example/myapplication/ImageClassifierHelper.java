package com.example.myapplication;

import android.graphics.Bitmap;

public class ImageClassifierHelper {
    public static Bitmap bitmap;  // This will hold the selected image temporarily
}
